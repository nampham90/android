package nampham.residenavigation;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.special.ResideMenu.ResideMenu;
import com.special.ResideMenu.ResideMenuItem;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ResideMenu resideMenu;
    private Context mContext;
    private ResideMenuItem itemHome;
    private ResideMenuItem itemProfile;
    private ResideMenuItem itemCalendar;
    private ResideMenuItem itemSettings;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext=this;
        setupMenu();
    }

    public void setupMenu(){
        resideMenu=new ResideMenu(this);
        resideMenu.setBackground(R.drawable.menu_background);
        resideMenu.attachToActivity(this);
        resideMenu.setMenuListener(menuListener);
        resideMenu.setScaleValue(0.5f);

        //create menu item
        itemHome=new ResideMenuItem(this,R.drawable.icon_home,"Home");
        itemProfile=new ResideMenuItem(this,R.drawable.icon_profile,"Profile");
        itemSettings=new ResideMenuItem(this,R.drawable.icon_settings,"Setting");
        itemCalendar=new ResideMenuItem(this,R.drawable.icon_calendar,"Calendar");

        itemHome.setOnClickListener(this);
        itemCalendar.setOnClickListener(this);
        itemSettings.setOnClickListener(this);
        itemProfile.setOnClickListener(this);

        resideMenu.addMenuItem(itemHome,ResideMenu.DIRECTION_LEFT);
        resideMenu.addMenuItem(itemCalendar,ResideMenu.DIRECTION_LEFT);
        resideMenu.addMenuItem(itemProfile,ResideMenu.DIRECTION_RIGHT);
        resideMenu.addMenuItem(itemSettings,ResideMenu.DIRECTION_RIGHT);

        findViewById(R.id.title_bar_left_mneu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resideMenu.openMenu(ResideMenu.DIRECTION_LEFT);
            }
        });
        findViewById(R.id.title_bar_right_menu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resideMenu.openMenu(ResideMenu.DIRECTION_RIGHT);
            }
        });

    }
    private ResideMenu.OnMenuListener menuListener =new ResideMenu.OnMenuListener(){
        @Override
        public void openMenu() {
            Toast.makeText(MainActivity.this, "open Menu !", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void closeMenu() {
            Toast.makeText(MainActivity.this, "close Menu !", Toast.LENGTH_SHORT).show();
        }
    };
    @Override
    public void onClick(View view) {
        if (view == itemHome){
            changeFragment(new HomeFragment());
        }else if (view == itemProfile){
            changeFragment(new ProfileFragment());
        }else if (view == itemCalendar){
            changeFragment(new CarendarFragment());
        }else if (view == itemSettings){
            changeFragment(new SettingFragment());
        }

        resideMenu.closeMenu();


    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        return resideMenu.dispatchTouchEvent(ev);
    }

    private void changeFragment(Fragment targetFragment){
        resideMenu.clearIgnoredViewList();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.main_fragment, targetFragment, "fragment")
                .setTransitionStyle(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .commit();
    }
    public ResideMenu getResideMenu(){
        return resideMenu;
    }

}
